# Bupe Marvine Portfolio

A responsive personal portfolio website built with HTML, CSS and JavaScript.

## Files
- `index.html` — website structure and content
- `style.css` — responsive design and styling
- `script.js` — mobile navigation and dynamic year

## How to run
1. Extract the folder.
2. Open `index.html` in a web browser.

## Before publishing
Replace the placeholder GitHub and LinkedIn links in `index.html` with your real profile URLs.
Replace the sample project descriptions with your actual projects and repository links.

## Suggested hosting
You can publish this site using GitHub Pages, Netlify, Vercel or another static hosting provider.
